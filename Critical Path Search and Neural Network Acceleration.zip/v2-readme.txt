ACM Transactions on Graphics - V2 (April 2012)
----------------------------------------------

The following files are available in the v2-acmtog.zip archive:

acmtog.cls	     			- This is V1.2 of the LaTeX2e class file for the 'acmtog' format
ACM-Reference-Format-Journals.bst	- This is the bibliography style file for the New ACM Reference Format (March 2012)
acmtog-sample-bibfile.bib		- This is the bibliography database file
v2-acmtog-guide.pdf			- This is a PDF of the "author guidelines' for the acmtog template
v2-acmtog-sample.pdf			- This is a PDF file showing what YOU should obtain
					  when YOU compile the sample source .tex file

v2-acmtog-sample.tex			- the revised (v2) source sample .tex file 
v2-acmtog-sample.bbl			- the bbl file as a result of 'BibTeX'ing 
tog-sample-mouse.eps			- Graphics file used in sample
tog-sample-mouse.pdf			- a graphics file in PDF format, (compatible with pdflatex)
algorithm2e.sty				- Algorithm package used in sample
url.sty					- URL package used in formatting the references
readme.txt				- This file!

Happy (La)TeXing!!!

Aptara/Gerry Murray - April 2012
